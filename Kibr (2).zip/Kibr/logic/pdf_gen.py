from fpdf import FPDF
import io
import os

class CryptoPDF(FPDF):
    def header(self):
        # Background color for header
        self.set_fill_color(11, 15, 26)
        self.rect(0, 0, 210, 35, 'F')
        
        self.set_font('Helvetica', 'B', 18)
        self.set_text_color(99, 102, 241) # Indigo
        self.set_y(10)
        self.cell(0, 10, 'CRYPTOGRAPHIC LABORATORY', ln=1, align='C')
        self.set_font('Helvetica', 'B', 12)
        self.set_text_color(255, 255, 255)
        self.cell(0, 8, 'Akademik Tadqiqot va O\'quv Qo\'llanmasi', ln=1, align='C')
        self.ln(12)

    def footer(self):
        self.set_y(-25)
        self.set_draw_color(99, 102, 241)
        self.line(10, self.get_y(), 200, self.get_y())
        self.ln(2)
        self.set_font('Helvetica', 'I', 8)
        self.set_text_color(100)
        self.cell(0, 10, 'Ushbu hujjat Crypt Lab V2.0 tomonidan avtomatik generatsiya qilingan.', ln=0, align='L')
        self.cell(0, 10, f'Sahifa {self.page_no()}', 0, 0, 'R')

    def chapter_title(self, label):
        self.set_font('Helvetica', 'B', 16)
        self.set_fill_color(240, 240, 255)
        self.set_text_color(0, 0, 0)
        self.cell(0, 12, f'  {label}', ln=1, align='L', fill=True)
        self.ln(4)

    def chapter_body(self, body):
        self.set_font('Helvetica', '', 12)
        self.set_text_color(40, 40, 40)
        # Handle unicode-ish chars for Uzbek
        clean_body = body.replace('’', "'").replace('‘', "'").replace('“', '"').replace('”', '"')
        self.multi_cell(0, 8, clean_body)
        self.ln()

def generate_academic_pdf(title, sections, image_path=None):
    """
    sections: list of dicts with {'title': '...', 'content': '...'}
    """
    pdf = CryptoPDF()
    pdf.add_page()
    
    # Main Title
    pdf.set_font('Helvetica', 'B', 24)
    pdf.set_text_color(31, 41, 55)
    pdf.ln(10)
    pdf.cell(0, 20, title.upper(), ln=1, align='L')
    pdf.set_draw_color(99, 102, 241)
    pdf.set_line_width(1)
    pdf.line(10, pdf.get_y(), 100, pdf.get_y())
    pdf.ln(10)

    # Image if provided
    if image_path and os.path.exists(image_path):
        try:
            # Place image at the top right or center
            pdf.image(image_path, x=130, y=50, w=70)
        except:
            pass

    # Render Sections
    for section in sections:
        pdf.chapter_title(section['title'])
        pdf.chapter_body(section['content'])
        
    return bytes(pdf.output())
