import streamlit as st
import streamlit.components.v1 as components
from logic import classical, rsa, hashing, pdf_gen
import ast

# Page Configuration
st.set_page_config(
    page_title="Cryptographic Lab",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="collapsed"
)

# Load CSS
def local_css(file_name):
    with open(file_name) as f:
        st.markdown(f'<style>{f.read()}</style>', unsafe_allow_html=True)

local_css("assets/styles.css")

# Session State Initialization
if 'page' not in st.session_state:
    st.session_state.page = 'Home'

# Navigation Function
def set_page(name):
    st.session_state.page = name

# Custom Header (HTML)
def render_header():
    # Floating Nav Bar Structure
    st.markdown(f"""
        <div class="top-nav">
            <div class="nav-brand">
                <i class="fa-solid fa-shield-halved"></i> 
                <span>CRYPT LAB</span>
            </div>
            <div class="nav-links">
                <!-- Links handled by Streamlit buttons below -->
            </div>
        </div>
    """, unsafe_allow_html=True)
    
    # Navigation Buttons centered via columns
    cols = st.columns([2.5, 0.8, 0.8, 0.8, 0.8, 1, 2.5])
    with cols[1]:
        if st.button("Asosiy", key="nav_home", use_container_width=True):
            set_page('Home')
    with cols[2]:
        if st.button("Klassik", key="nav_classic", use_container_width=True):
            set_page('Classical')
    with cols[3]:
        if st.button("RSA", key="nav_rsa", use_container_width=True):
            set_page('RSA')
    with cols[4]:
        if st.button("Xesh", key="nav_hash", use_container_width=True):
            set_page('Hash')
    with cols[5]:
        if st.button("Kutubxona", key="nav_lib", use_container_width=True):
            set_page('Library')

# --- PAGE RENDERING FUNCTIONS ---

def render_home():
    st.markdown("""
        <div class="hero fade-in">
            <h1>Advanced <span style="color: #6366f1;">Cryptographic</span> Lab</h1>
            <p>Xavfsiz ma'lumotlar olamiga xush kelibsiz. Bu yerda siz kriptografiyaning klassik va modern usullarini o'rganishingiz mumkin.</p>
        </div>
    """, unsafe_allow_html=True)
    
    # Stats with Icons
    st.markdown("""
        <div class="stats-container fade-in" style="animation-delay: 0.2s;">
            <div class="glass-card stat-item">
                <div class="stat-value"><i class="fa-solid fa-microchip"></i> 5+</div>
                <div class="stat-label">Algoritmlar</div>
            </div>
            <div class="glass-card stat-item">
                <div class="stat-value"><i class="fa-solid fa-key"></i> 256-bit</div>
                <div class="stat-label">Xavfsizlik</div>
            </div>
            <div class="glass-card stat-item">
                <div class="stat-value"><i class="fa-solid fa-code-branch"></i> 100%</div>
                <div class="stat-label">Ochiq Manba</div>
            </div>
        </div>
    """, unsafe_allow_html=True)
    
    st.markdown("""
        <div class="banner fade-in" style="animation-delay: 0.4s;">
            <i class="fa-solid fa-graduation-cap" style="color: #818cf8;"></i>
            <div>
                <span style="font-weight: 700;">YANGILIK:</span> 
                Akademik darajadagi PDF qo'llanmalar va chuqurlashtirilgan nazariya qo'shildi!
            </div>
        </div>
    """, unsafe_allow_html=True)

def render_classical():
    st.markdown('<div class="glass-card fade-in"><h2><i class="fa-solid fa-feather"></i> Klassik Shifrlar</h2></div>', unsafe_allow_html=True)
    
    tabs = st.tabs(["Sezar Shifri", "Vigenere Shifri"])
    
    with tabs[0]:
        col1, col2 = st.columns(2)
        with col1:
            text = st.text_area("Ma'lumot", placeholder="Matnni kiriting...", key="caesar_input")
            shift = st.slider("Siljish (Shift)", 1, 25, 3)
        with col2:
            mode = st.radio("Amal", ["Shifrlash", "Deshifrlash"], key="caesar_mode")
            if text:
                m = 'encrypt' if mode == "Shifrlash" else 'decrypt'
                res = classical.caesar_cipher(text, shift, m)
                render_result("Natija", res)

    with tabs[1]:
        col1, col2 = st.columns(2)
        with col1:
            v_text = st.text_area("Ma'lumot", placeholder="Matnni kiriting...", key="vigenere_input")
            v_key = st.text_input("Kalit so'z", placeholder="Masalan: SECRET", key="vigenere_key")
        with col2:
            v_mode = st.radio("Amal", ["Shifrlash", "Deshifrlash"], key="vigenere_mode")
            if v_text and v_key:
                m = 'encrypt' if v_mode == "Shifrlash" else 'decrypt'
                res = classical.vigenere_cipher(v_text, v_key, m)
                render_result("Natija", res)

def render_rsa():
    st.markdown('<div class="glass-card fade-in"><h2><i class="fa-solid fa-lock"></i> RSA Algoritmi</h2></div>', unsafe_allow_html=True)
    
    rsa_tabs = st.tabs(["🔑 Kalitlar Yaratish", "🔒 Shifrlash", "🔓 Deshifrlash", "📖 Qadamma-qadam Tushuntirish"])
    
    with rsa_tabs[0]:
        col1, col2 = st.columns(2)
        with col1:
            st.subheader("🔑 Kalitlarni Generatsiya Qilish")
            mode = st.toggle("Professional Rejim (Avtomatik)", value=True)
            
            if mode:
                bits = st.select_slider("Kalit uzunligi (bits)", options=[512, 1024, 2048], value=1024)
                if st.button("Xavfsiz Kalitlarni Yaratish"):
                    with st.spinner("Murakkab matematik hisob-kitoblar bajarilmoqda..."):
                        manager = rsa.RSAManager(bits=bits)
                        manager.generate_keys()
                        st.session_state.rsa_manager = manager
                        st.session_state.rsa_public = (manager.e, manager.n)
                        st.session_state.rsa_private = (manager.d, manager.n)
                        st.success(f"✅ {bits}-bitli xavfsiz kalitlar yaratildi!")
            else:
                st.write("RSA uchun p va q tub sonlarini tanlang.")
                p = st.number_input("P (Tub son)", value=61, min_value=11)
                q = st.number_input("Q (Tub son)", value=53, min_value=11)
                if st.button("Kalitlarni Generatsiya Qilish"):
                    try:
                        # Legacy generation but wrap in manager for consistent logic
                        public, private = rsa.generate_keypair(p, q)
                        manager = rsa.RSAManager(bits=(p*q).bit_length())
                        manager.e, manager.n = public
                        manager.d, manager.n = private
                        # Setup CRT for the manager
                        phi = (p-1)*(q-1)
                        manager.p, manager.q = p, q
                        manager.dp = manager.d % (p - 1)
                        manager.dq = manager.d % (q - 1)
                        manager.qinv = rsa.mod_inverse(q, p)
                        
                        st.session_state.rsa_manager = manager
                        st.session_state.rsa_public = public
                        st.session_state.rsa_private = private
                        st.success("Kalitlar yaratildi!")
                    except Exception as e:
                        st.error(f"Xatolik: {str(e)}")
        
        with col2:
            st.subheader("📡 Joriy Kalitlar")
            if 'rsa_public' in st.session_state:
                st.info(f"**Ochiq Kalit (e, n):**\n`{st.session_state.rsa_public}`")
                st.warning(f"**Yopiq Kalit (d, n):**\n`{st.session_state.rsa_private}`")
                if 'rsa_manager' in st.session_state and st.session_state.rsa_manager.p > 0:
                    pass
            else:
                st.info("Hali kalitlar yaratilmagan. Chap tarafdagi tugmani bosing.")

    with rsa_tabs[1]:
        st.subheader("🔒 Ma'lumotni Shifrlash (OAEP)")
        encrypt_text = st.text_area("Shifrlash uchun matn", placeholder="Maxfiy xabarni kiriting...", key="enc_text")
        
        if st.button("Shifrlash", key="btn_encrypt", use_container_width=True):
            if encrypt_text and 'rsa_manager' in st.session_state:
                try:
                    manager = st.session_state.rsa_manager
                    cipher = manager.encrypt(encrypt_text)
                    st.session_state.last_rsa_cipher = str(cipher)
                    st.session_state.last_rsa_mode = "OAEP"
                    st.success("✅ Shifrlash OAEP padding bilan bajarildi!")
                except ValueError as ve:
                    if "Kalit juda kichik" in str(ve):
                        # Fallback to Textbook RSA
                        manager = st.session_state.rsa_manager
                        cipher = manager.textbook_encrypt(encrypt_text)
                        st.session_state.last_rsa_cipher = str(cipher)
                        st.session_state.last_rsa_mode = "Textbook"
                        st.warning(f"""
                            ⚠️ **Zaif Shifrlash Rejimi Faollashtirildi**
                            
                            Kalit juda kichik bo'lgani uchun xavfsiz OAEP padding ishlatib bo'lmadi. 
                            Tizim **'Textbook RSA'** (soda) usuliga o'tdi. Bu usul professional darajada xavfsiz emas!
                        """)
                    else:
                        st.error(f"Xatolik: {str(ve)}")
                except Exception as e:
                    st.error(f"Xatolik: {str(e)}")
            elif not encrypt_text:
                st.error("Matnni kiriting!")
            else:
                st.error("Avval kalitlarni yarating!")
        
        if 'last_rsa_cipher' in st.session_state:
            render_result("Shifrlangan Matn (Ciphertext)", st.session_state.last_rsa_cipher)

    with rsa_tabs[2]:
        st.subheader("🔓 Ma'lumotni Deshifrlash (CRT)")
        decrypt_input = st.text_area("Shifrlangan sonni kiriting", value=st.session_state.get('last_rsa_cipher', ""), key="dec_input")
        
        if st.button("Deshifrlash", key="btn_decrypt", use_container_width=True):
            if decrypt_input and 'rsa_manager' in st.session_state:
                try:
                    manager = st.session_state.rsa_manager
                    # Check which mode we are in based on input format
                    if decrypt_input.startswith("["):
                        # Textbook mode (list of ints)
                        import ast
                        cipher_list = ast.literal_eval(decrypt_input)
                        decrypted = manager.textbook_decrypt(cipher_list)
                        st.success("✅ Deshifrlash (Textbook) yakunlandi!")
                    else:
                        # Professional mode (single large int)
                        ciphertext = int(decrypt_input)
                        decrypted = manager.decrypt(ciphertext)
                        st.success("✅ Deshifrlash (CRT + OAEP) yakunlandi!")
                    
                    st.session_state.last_rsa_decrypted = decrypted
                except Exception as e:
                    st.error(f"Xatolik: {str(e)}")
            elif not decrypt_input:
                st.error("Shifrlangan ma'lumotni kiriting!")
            else:
                st.error("Kalitlar mavjud emas!")
        
        if 'last_rsa_decrypted' in st.session_state:
            render_result("Asl Ma'lumot", st.session_state.last_rsa_decrypted)

    with rsa_tabs[3]:
        st.subheader("📖 RSA Matematik Jarayoni Vizualizatsiyasi")
        st.write("Bu yerda professional RSA dagi 'parda ortidagi' amallarni kuzatishingiz mumkin.")
        
        if 'rsa_manager' not in st.session_state:
            st.warning("Avval 'Kalitlar Yaratish' bo'limida kalit yarating.")
        else:
            manager = st.session_state.rsa_manager
            
            # Stage 1: Prime Generation
            with st.expander("1-Bosqich: Katta Tub Sonlar Qayerdan Keladi?"):
                st.markdown("""
                    Professional RSA da $p$ va $q$ shunchaki tanlanmaydi, balki tasodifiy generatsiya qilinib, **Miller-Rabin** testi orqali tekshiriladi.
                """)
                col1, col2 = st.columns(2)
                with col1:
                    st.info(f"**P:** {str(manager.p)[:30]}...")
                    st.write(f"Bit uzunligi: {manager.p.bit_length()} bit")
                with col2:
                    st.info(f"**Q:** {str(manager.q)[:30]}...")
                    st.write(f"Bit uzunligi: {manager.q.bit_length()} bit")
                
                st.markdown("""
                    **Miller-Rabin Algoritmi:** Bu ehtimollikka asoslangan test bo'lib, sonning tubligini bir necha raund davomida tekshiradi. 
                    Agar son testdan o'tsa, u **'Prime Candidate'** (Tublikka nomzod) deb ataladi.
                """)

            # Stage 2: Modulus & Phi
            with st.expander("2-Bosqich: Modul ($n$) va Eyler Funksiyasi ($\phi$)"):
                st.latex(rf"n = p \times q = {manager.n}")
                phi = (manager.p - 1) * (manager.q - 1)
                st.latex(rf"\phi(n) = (p-1)(q-1) = {phi}")
                
                st.markdown("---")
                st.markdown("**CRT (Chinese Remainder Theorem) parametrlari:**")
                st.latex(rf"dp = d \pmod{{(p-1)}} = {manager.dp}")
                st.latex(rf"dq = d \pmod{{(q-1)}} = {manager.dq}")
                st.markdown("""
                    Bu parametrlar deshifrlashni tezlashtirish uchun kerak. 
                    Katta $d$ darajasiga ko'tarish o'rniga, kichikroq $dp$ va $dq$ darajalaridan foydalaniladi.
                """)

            # Stage 3: EEA Calculation for d
            with st.expander("3-Bosqich: Kengaytirilgan Evklid Algoritmi (EEA)"):
                st.markdown(f"Bizga shunday $d$ kerakki: $e \cdot d \equiv 1 \pmod{{\phi(n)}}$. Hozirgi $e = {manager.e}$.")
                
                # Use current keys for EEA table
                demo_a, demo_b = manager.e, phi
                
                from logic.prime_utils import extended_gcd_steps
                _, x, _, steps = extended_gcd_steps(demo_a, demo_b)
                
                import pandas as pd
                df_steps = pd.DataFrame(steps)
                # Convert all columns to string to avoid "int too big to convert" OverflowError
                df_steps = df_steps.astype(str)
                
                if len(df_steps) > 15:
                    st.info(f"💡 Algoritm juda ko'p ({len(df_steps)}) qadamdan iborat. Dastlabki va oxirgi qadamlarni ko'rsatamiz:")
                    st.table(pd.concat([df_steps.head(5), df_steps.tail(5)]))
                else:
                    st.table(df_steps)
                
                st.success(f"Natijada hisoblangan modular inverse $d$: {manager.d}")
                st.markdown(f"**Isbot:** $({manager.e} \\times {manager.d}) \\pmod{{{phi}}} = 1$")

            # Stage 4: Encryption Logic (OAEP vs Textbook)
            with st.expander("4-Bosqich: Shifrlash Strategiyasi"):
                k = manager.bits // 8
                hLen = 32
                if k < 2 * hLen + 2:
                    st.warning("⚠️ Kichik tub sonlar ishlatilmoqda. OAEP padding uchun joy yetarli emas.")
                    st.markdown("""
                        Siz tanlagan sonlar juda kichik bo'lgani uchun tizim **'Textbook RSA'** (oddiy darajaga ko'tarish) usulidan foydalanadi.
                        Matematik formula: $C = M^e \pmod n$
                    """)
                    sample_m = 42
                    st.latex(rf"C = {sample_m}^{{{manager.e}}} \pmod{{{manager.n}}} = {pow(sample_m, manager.e, manager.n)}")
                else:
                    st.success("✅ Professional RSA (OAEP) rejimi faol.")
                    st.markdown("""
                        Katta sonlar bilan biz **OAEP** ishlatamiz. Bu xabarni quyidagicha o'zgartiradi:
                        1. Xabarga tasodifiy 'Seed' qo'shiladi.
                        2. XOR operatsiyalari orqali xabar taniy bo'lmas darajaga keltiriladi.
                        3. Faqat shundan keyin darajaga ko'tariladi.
                    """)

def render_hash():
    st.markdown('<div class="glass-card fade-in"><h2><i class="fa-solid fa-fingerprint"></i> Xesh Funksiyalar (SHA-256)</h2></div>', unsafe_allow_html=True)
    
    st.subheader("Avalanche Effect (Ko'chki Effekti)")
    t1 = st.text_input("1-Matn", value="Salom Dunyo")
    t2 = st.text_input("2-Matn (O'zgartirilgan)", value="Salom Dunya")
    
    if t1 and t2:
        result = hashing.avalanche_effect(t1, t2)
        
        c1, c2 = st.columns(2)
        with c1:
            st.markdown("**1-Xesh:**")
            st.code(result['hash1'])
        with c2:
            st.markdown("**2-Xesh:**")
            st.code(result['hash2'])
            
        st.markdown(f"""
            <div class="glass-card" style="text-align: center;">
                <h3 style="color: #818cf8;">O'zgarish Darajasi</h3>
                <div style="font-size: 3rem; font-weight: 700;">{result['percentage']}%</div>
                <p>{result['diff_bits']} bit 256 tadan farq qiladi.</p>
            </div>
        """, unsafe_allow_html=True)

def render_library():
    st.markdown('<div class="glass-card fade-in"><h2><i class="fa-solid fa-book-bookmark"></i> Kriptografiya Kutubxonasi</h2></div>', unsafe_allow_html=True)
    
    techs = [
        {
            "id": "caesar",
            "title": "Sezar Shifri",
            "short": "Alifbo harflarini ma'lum bir pozitsiyaga siljitish usuli.",
            "sections": [
                {"title": "1. Sarlavha va Kirish", "content": "Sezar shifri - tarixdagi eng qadimgi va eng mashhur shifrlash usullaridan biridir. Miloddan avvalgi 1-asrda Yuliy Sezar tomonidan harbiy xabarlarni himoya qilish uchun foydalanilgan. Uning asosiy vazifasi oddiy matnni alifbodagi harflarni siljitish orqali taniy bo'lmas holatga keltirishdir."},
                {"title": "2. Matematik Model", "content": "Sezar shifri o'rin almashtirish (substitution) tamoyiliga asoslanadi. Har bir harf alifboda K masofaga siljitiladi. Matematik ifodasi:\nShifrlash: C = (P + K) mod 26\nDeshifrlash: P = (C - K) mod 26\nBu yerda P - asl harf raqami, C - shifrlangan harf, K - kalit (siljish miqdori)."},
                {"title": "3. Texnik Xususiyatlar va Effektlar", "content": "Bu algoritm monoalfavitli hisoblanadi, ya'ni bir xil harf har doim bir xil natijaga shifrlanadi. Bu esa chastotali tahlil (frequency analysis) yordamida shifrni oson buzilishiga olib keladi. Kalitlar fazosi juda kichik (atigi 25 ta imkoniyat)."},
                {"title": "4. Amaliy Qo'llanilishi", "content": "Bugungi kunda Sezar shifri amaliy kiberxavfsizlikda ishlatilmaydi, lekin u kriptografiya asoslarini o'rgatishda va ROT13 kabi sodda tizimlarda bazaviy tushuncha sifatida xizmat qiladi."},
                {"title": "5. Vizualizatsiya", "content": "Diagramma tavsifi: Ikkita konsentrik alifbo halqasi tasvirlanadi. Ichki halqa tashqi halqaga nisbatan K qadamga aylantirilgan. Har bir tashqi harf o'ziga mos keluvchi ichki harfga yo'naltirilgan."}
            ],
            "img": "caesar_cipher_diagram_1776755063450.png"
        },
        {
            "id": "vigenere",
            "title": "Vigenere Shifri",
            "short": "Polialfavitli shifrlash tizimi (Murakkab Sezar).",
            "sections": [
                {"title": "1. Sarlavha va Kirish", "content": "Vigenere shifri - polialfavitli almashtirish usuli bo'lib, bir necha asrlar davomida 'buzib bo'lmas shifr' deb hisoblangan. U 16-asrda Blez de Vigenere tomonidan takomillashtirilgan. U Sezar shifrini bir nechta kalitlar yordamida yanada murakkablashtiradi."},
                {"title": "2. Matematik Model", "content": "Vigenere shifri kalit so'zdan foydalanadi. Har bir matn harfi kalitning mos harfiga qarab siljitiladi. Matematik formula:\nC[i] = (P[i] + K[i mod L]) mod 26\nBu yerda L - kalit so'zning uzunligi. Bu usul har bir harfning turli miqdorda siljishini ta'minlaydi."},
                {"title": "3. Texnik Xususiyatlar va Effektlar", "content": "Polialfavitli tabiat harflarning statistik chastotasini yashiradi. Agar kalit uzun va takrorlanmaydigan bo'lsa, xavfsizlik darajasi juda yuqori bo'ladi. Kalit uzunligini aniqlash uchun Kasiski testi kabi usullar qo'llaniladi."},
                {"title": "4. Amaliy Qo'llanilishi", "content": "Vigenere shifri klassik kriptografiya tarixida burilish nuqtasi bo'lgan. Hozirgi kunda u ochiq kalitli tizimlar o'rnini egallagan bo'lsa-da, u tushunish oson bo'lgan murakkab simmetrik tizim sifatida o'qitiladi."},
                {"title": "5. Vizualizatsiya", "content": "Diagramma tavsifi: 'Tabula Recta' - 26x26 o'lchamli alifbo jadvali. Satrlar - matn harflari, ustunlar - kalit harflari. Ularning kesishish nuqtasi shifrlangan harfni beradi."}
            ],
            "img": None
        },
        {
            "id": "rsa",
            "title": "RSA Algoritmi",
            "short": "Ochiq kalitli asimmetrik shifrlash texnologiyasi.",
            "sections": [
                {"title": "1. Sarlavha va Kirish", "content": "RSA (Rivest-Shamir-Adleman) - dunyodagi birinchi va eng mashhur asimmetrik kriptotizim. 1977 yilda kashf etilgan ushbu algoritm zamonaviy kiberxavfsizlikning asosi hisoblanadi. U ochiq aloqa kanallari orqali xavfsiz ma'lumot almashish imkonini beradi."},
                {"title": "2. Matematik Model", "content": "RSA ikki katta tub sonning ko'paytmasini faktorlarga ajratish qiyinligiga asoslangan.\n1. n = p * q, phi = (p-1)*(q-1)\n2. e tanlanadi: gcd(e, phi) = 1\n3. d topiladi: e*d = 1 mod phi\nShifrlash: C = M^e mod n\nDeshifrlash: M = C^d mod n"},
                {"title": "3. Texnik Xususiyatlar va Effektlar", "content": "RSA asimmetrik tizim bo'lib, ikkita kalit (ochiq va maxfiy) ishlatadi. OAEP padding usuli 'Textbook RSA' zaifliklarini bartaraf etish uchun zarur. Kalit uzunligi kamida 2048 bit bo'lishi tavsiya etiladi."},
                {"title": "4. Amaliy Qo'llanilishi", "content": "RSA bugun SSL/TLS (HTTPS), raqamli imzolar va SSH protokollarida keng qo'llaniladi. U onlayn bank tizimlari va elektron tijorat xavfsizligini ta'minlovchi asosiy texnologiyadir."},
                {"title": "5. Vizualizatsiya", "content": "Diagramma tavsifi: Alisa va Bob o'rtasidagi aloqa. Alisa Bobning ochiq kaliti bilan shifrlaydi, Bob esa o'zining yopiq kaliti bilan ochadi. Kalitlar juftligi va modul amali markaziy o'rinni egallaydi."}
            ],
            "img": None
        },
        {
            "id": "sha256",
            "title": "SHA-256 Xesh",
            "short": "Ma'lumotlar yaxlitligini tekshirish uchun xavfsiz xesh.",
            "sections": [
                {"title": "1. Sarlavha va Kirish", "content": "SHA-256 (Secure Hash Algorithm 256) - ma'lumotlarning qaytmas 'barmoq izi'ni yaratuvchi funksiya. NIST tomonidan standartlashtirilgan. U har qanday uzunlikdagi ma'lumotni 256-bitli (32 bayt) qat'iy uzunlikdagi natijaga aylantiradi."},
                {"title": "2. Matematik Model", "content": "Algoritm 512-bitli bloklarda ishlaydi va 64 raunddan iborat siqish funksiyasini qo'llaydi. Asosiy mantiqiy amallar:\n- XOR, AND, NOT\n- ROTR (Rotate Right) va SHR (Shift Right)\n- Modulo 2^32 qo'shish amali. Bu amallar ma'lumotni qaytarib bo'lmas darajada aralashtirib tashlaydi."},
                {"title": "3. Texnik Xususiyatlar va Effektlar", "content": "Eng muhim xususiyati - 'Ko'chki effekti' (Avalanche Effect). Agar kiruvchi ma'lumotning birgina biti o'zgarsa, natija (xesh) butunlay o'zgaradi. Shuningdek, u to'qnashuvga (collision) chidamlidir."},
                {"title": "4. Amaliy Qo'llanilishi", "content": "SHA-256 blokcheyn texnologiyasi (Bitcoin mining), parollarni xavfsiz saqlash va dasturiy ta'minotning yaxlitligini (checksum) tekshirishda standart hisoblanadi."},
                {"title": "5. Vizualizatsiya", "content": "Diagramma tavsifi: Kiruvchi xabar bloklarga bo'linadi, har bir blok siqish funksiyasi orqali o'tadi va oldingi blokning natijasi bilan 'XOR' amali orqali bog'lanadi (Merkle-Damgard tuzilmasi)."}
            ],
            "img": None
        }
    ]
    
    cols = st.columns(2)
    for i, tech in enumerate(techs):
        with cols[i % 2]:
            with st.container(border=True):
                st.markdown(f"### {tech['title']}")
                st.write(tech['short'])
                
                # Academic PDF Download
                pdf_bytes = pdf_gen.generate_academic_pdf(tech['title'], tech['sections'], tech['img'])
                st.download_button(
                    label="🎓 Akademik PDF Yuklab Olish",
                    data=pdf_bytes,
                    file_name=f"{tech['id']}_academic_guide.pdf",
                    mime="application/pdf"
                )

# Helper for styled result containers
def render_result(title, content, type="success"):
    icon = "check-double" if type == "success" else "triangle-exclamation"
    color = "#10b981" if type == "success" else "#f59e0b"
    st.markdown(f"""
        <div class="glass-card fade-in" style="padding: 1.5rem; margin-top: 1rem; border-left: 4px solid {color};">
            <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 0.5rem; color: {color};">
                <i class="fa-solid fa-{icon}"></i>
                <span style="font-weight: 700; text-transform: uppercase; font-size: 0.8rem; letter-spacing: 1px;">{title}</span>
            </div>
            <div style="font-family: 'JetBrains Mono', monospace; background: rgba(0,0,0,0.2); padding: 1rem; border-radius: 12px; word-break: break-all;">
                {content}
            </div>
        </div>
    """, unsafe_allow_html=True)

# Main App Logic
render_header()
st.markdown('<div style="height: 20px;"></div>', unsafe_allow_html=True)
if st.session_state.page == 'Home':
    render_home()
elif st.session_state.page == 'Classical':
    render_classical()
elif st.session_state.page == 'RSA':
    render_rsa()
elif st.session_state.page == 'Hash':
    render_hash()
elif st.session_state.page == 'Library':
    render_library()
