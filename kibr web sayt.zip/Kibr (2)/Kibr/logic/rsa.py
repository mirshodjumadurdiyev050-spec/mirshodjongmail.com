import hashlib
import os
import math
from logic.prime_utils import generate_prime, mod_inverse, modular_exponentiation, gcd

class RSAManager:
    def __init__(self, bits=1024):
        self.bits = bits
        self.n = 0
        self.e = 65537
        self.d = 0
        self.p = 0
        self.q = 0
        # CRT (Chinese Remainder Theorem) optimallashtirish uchun
        self.dp = 0
        self.dq = 0
        self.qinv = 0

    def generate_keys(self):
        """Kuchsiz 'Textbook RSA' dan farqli ravishda, xavfsiz kalitlarni generatsiya qiladi."""
        while True:
            self.p = generate_prime(self.bits // 2)
            self.q = generate_prime(self.bits // 2)
            if self.p != self.q:
                self.n = self.p * self.q
                phi = (self.p - 1) * (self.q - 1)
                if gcd(self.e, phi) == 1:
                    break
        
        self.d = mod_inverse(self.e, phi)
        
        # CRT parametrlari
        self.dp = self.d % (self.p - 1)
        self.dq = self.d % (self.q - 1)
        self.qinv = mod_inverse(self.q, self.p)
        
        return (self.e, self.n), (self.d, self.n)

    def _mgf1(self, seed, length):
        """Mask Generation Function (MGF1) SHA-256 bilan."""
        hLen = 32 # SHA-256 hash length in bytes
        if length > (2**32) * hLen:
            raise ValueError("Mask length too long")
        
        T = b""
        for i in range(math.ceil(length / hLen)):
            C = i.to_bytes(4, byteorder='big')
            T += hashlib.sha256(seed + C).digest()
        return T[:length]

    def _xor_bytes(self, b1, b2):
        return bytes(a ^ b for a, b in zip(b1, b2))

    def oaep_pad(self, message):
        """OAEP padding (PKCS#1 v2.1)."""
        k = self.bits // 8
        hLen = 32
        mLen = len(message)
        
        if k < 2 * hLen + 2:
            raise ValueError(f"Kalit juda kichik! OAEP xavfsizlik standarti uchun modul kamida {2 * hLen + 2} bayt (528 bit) bo'lishi shart. Hozirgi kalit: {k} bayt ({self.bits} bit).")
            
        if mLen > k - 2 * hLen - 2:
            raise ValueError(f"Xabar juda uzun! Hozirgi kalit bilan maksimal {max(0, k - 2*hLen - 2)} bayt shifrlash mumkin.")
        
        lHash = hashlib.sha256(b"").digest()
        ps = b"\x00" * (k - mLen - 2 * hLen - 2)
        db = lHash + ps + b"\x01" + message
        
        seed = os.urandom(hLen)
        db_mask = self._mgf1(seed, k - hLen - 1)
        masked_db = self._xor_bytes(db, db_mask)
        
        seed_mask = self._mgf1(masked_db, hLen)
        masked_seed = self._xor_bytes(seed, seed_mask)
        
        return b"\x00" + masked_seed + masked_db

    def oaep_unpad(self, padded_message):
        """OAEP paddingni olib tashlash."""
        k = self.bits // 8
        hLen = 32
        
        if len(padded_message) != k:
            raise ValueError("Noto'g'ri padding uzunligi.")
            
        _, masked_seed, masked_db = padded_message[0:1], padded_message[1:hLen+1], padded_message[hLen+1:]
        
        seed_mask = self._mgf1(masked_db, hLen)
        seed = self._xor_bytes(masked_seed, seed_mask)
        
        db_mask = self._mgf1(seed, k - hLen - 1)
        db = self._xor_bytes(masked_db, db_mask)
        
        lHash = hashlib.sha256(b"").digest()
        lHash_prime = db[:hLen]
        
        if lHash != lHash_prime:
            raise ValueError("Integrity check failed (OAEP lHash mismatch).")
            
        # 0x01 separatorini topish
        i = hLen
        while i < len(db) and db[i] == 0:
            i += 1
            
        if i == len(db) or db[i] != 1:
            raise ValueError("Invalid OAEP padding structure.")
            
        return db[i+1:]

    def encrypt(self, plaintext):
        """Xabarni OAEP bilan shifrlash."""
        if isinstance(plaintext, str):
            plaintext = plaintext.encode()
        
        padded = self.oaep_pad(plaintext)
        m = int.from_bytes(padded, byteorder='big')
        c = pow(m, self.e, self.n)
        return c

    def decrypt(self, ciphertext):
        """Xabarni CRT yordamida dekriptizatsiya qilish."""
        # CRT optimallashtirish: d bilan pow qilish o'rniga p va q bilan alohida qilinadi
        m1 = pow(ciphertext, self.dp, self.p)
        m2 = pow(ciphertext, self.dq, self.q)
        
        h = (self.qinv * (m1 - m2)) % self.p
        m = m2 + h * self.q
        
        k = self.bits // 8
        padded_bytes = m.to_bytes(k, byteorder='big')
        return self.oaep_unpad(padded_bytes).decode()

    def textbook_encrypt(self, plaintext):
        """Oddiy 'Textbook' RSA (har bir belgi alohida). FAQAT TA'LIM UCHUN!"""
        return [pow(ord(c), self.e, self.n) for c in plaintext]

    def textbook_decrypt(self, ciphertext):
        """Oddiy 'Textbook' RSA dekriptizatsiyasi."""
        return "".join([chr(pow(c, self.d, self.n)) for c in ciphertext])

    @staticmethod
    def _parallel_encrypt_block(args):
        manager, block = args
        return manager.encrypt(block)

    @staticmethod
    def _parallel_decrypt_block(args):
        manager, block = args
        return manager.decrypt(block)

    def parallel_process(self, data, mode='encrypt', processes=4):
        """Katta hajmdagi ma'lumotlarni parallel ravishda shifrlash yoki dekriptizatsiya qilish."""
        from multiprocessing import Pool
        
        k = self.bits // 8
        hLen = 32
        max_mLen = k - 2 * hLen - 2
        
        if mode == 'encrypt':
            if isinstance(data, str):
                data = data.encode()
            # Ma'lumotni bloklarga bo'lish
            blocks = [data[i:i + max_mLen] for i in range(0, len(data), max_mLen)]
            with Pool(processes=processes) as pool:
                results = pool.map(self._parallel_encrypt_block, [(self, b) for b in blocks])
            return results
        else:
            # data bu shifrlangan bloklar ro'yxati
            with Pool(processes=processes) as pool:
                results = pool.map(self._parallel_decrypt_block, [(self, b) for b in data])
            return "".join(results)

# Eskisiga mos kelishi uchun yordamchi funksiyalar (Legacy support)
def generate_keypair(p, q):
    # Bu funksiya endi faqat berilgan p va q ni o'rnatadi
    manager = RSAManager(bits=(p*q).bit_length())
    manager.p = p
    manager.q = q
    manager.n = p * q
    phi = (p - 1) * (q - 1)
    manager.d = mod_inverse(manager.e, phi)
    manager.dp = manager.d % (p - 1)
    manager.dq = manager.d % (q - 1)
    manager.qinv = mod_inverse(q, p)
    return (manager.e, manager.n), (manager.d, manager.n)

def encrypt(pk, plaintext):
    e, n = pk
    manager = RSAManager(bits=n.bit_length())
    manager.e = e
    manager.n = n
    # Bu yerda biz OAEP ishlatmaymiz, chunki pk da faqat e va n bor
    # Lekin "Professional" modulda buni o'zgartirish kerak
    # Biz hozircha manager metodini chaqiramiz
    return [pow(ord(c), e, n) for c in plaintext] # Old logic compatibility

def decrypt(sk, ciphertext):
    d, n = sk
    # Old logic compatibility
    return "".join([chr(pow(c, d, n)) for c in ciphertext])
