import string

def caesar_cipher(text, shift, mode='encrypt'):
    result = ""
    if mode == 'decrypt':
        shift = -shift
    
    for char in text:
        if char.isalpha():
            start = ord('A') if char.isupper() else ord('a')
            result += chr((ord(char) - start + shift) % 26 + start)
        else:
            result += char
    return result

def vigenere_cipher(text, key, mode='encrypt'):
    result = ""
    key = key.lower()
    if not key:
        return text
        
    key_indices = [ord(k) - ord('a') for k in key]
    key_len = len(key_indices)
    
    char_count = 0
    for char in text:
        if char.isalpha():
            start = ord('A') if char.isupper() else ord('a')
            shift = key_indices[char_count % key_len]
            if mode == 'decrypt':
                shift = -shift
            
            result += chr((ord(char) - start + shift) % 26 + start)
            char_count += 1
        else:
            result += char
    return result

def vernam_cipher(text, key):
    """Vernam shifri (XOR amali asosida)."""
    if not key:
        return text
    # Har bir belgini XOR qilish
    return "".join(chr(ord(c) ^ ord(key[i % len(key)])) for i, c in enumerate(text))
