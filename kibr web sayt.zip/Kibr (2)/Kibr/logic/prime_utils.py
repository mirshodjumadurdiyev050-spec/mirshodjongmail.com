import random

def gcd(a, b):
    """Eng katta umumiy bo'luvchi (GCD)"""
    while b:
        a, b = b, a % b
    return a

def extended_gcd(a, b):
    """Kengaytirilgan Evklid Algoritmi.
    ax + by = gcd(a, b) tenglamasi uchun (gcd, x, y) qaytaradi.
    """
    if a == 0:
        return b, 0, 1
    gcd_val, x1, y1 = extended_gcd(b % a, a)
    x = y1 - (b // a) * x1
    y = x1
    return gcd_val, x, y

def extended_gcd_steps(a, b):
    """EEA qadamlarini kuzatish uchun (educational)."""
    steps = []
    r_old, r = a, b
    s_old, s = 1, 0
    t_old, t = 0, 1
    
    while r != 0:
        q = r_old // r
        steps.append({
            "r_old": r_old, "r": r, "q": q,
            "s_old": s_old, "s": s,
            "t_old": t_old, "t": t
        })
        r_old, r = r, r_old - q * r
        s_old, s = s, s_old - q * s
        t_old, t = t, t_old - q * t
        
    return r_old, s_old, t_old, steps

def mod_inverse(e, phi):
    """Modular inverse: d = e^-1 mod phi"""
    gcd_val, x, y = extended_gcd(e, phi)
    if gcd_val != 1:
        raise ValueError("Modular inverse mavjud emas!")
    return x % phi

def modular_exponentiation(base, exp, mod):
    """Binary Exponentiation (Square-and-Multiply) algoritmi.
    Python dagi pow(base, exp, mod) bilan bir xil ishlaydi.
    """
    res = 1
    base = base % mod
    while exp > 0:
        if exp % 2 == 1:
            res = (res * base) % mod
        base = (base * base) % mod
        exp //= 2
    return res

def miller_rabin(n, k=40):
    """Miller-Rabin tublik testi (probabilistic).
    n - tekshirilayotgan son, k - testlar soni.
    """
    if n <= 1: return False
    if n <= 3: return True
    if n % 2 == 0: return False

    # n - 1 = 2^r * d ko'rinishida yozish
    r, d = 0, n - 1
    while d % 2 == 0:
        r += 1
        d //= 2

    for _ in range(k):
        a = random.randint(2, n - 2)
        x = pow(a, d, n)
        if x == 1 or x == n - 1:
            continue
        for _ in range(r - 1):
            x = pow(x, 2, n)
            if x == n - 1:
                break
        else:
            return False
    return True

def generate_prime(bits):
    """Berilgan bit uzunligidagi tub sonni generatsiya qilish."""
    while True:
        p = random.getrandbits(bits)
        # Toq son bo'lishini ta'minlash va yuqori bitni 1 qilish
        p |= (1 << (bits - 1)) | 1
        if miller_rabin(p):
            return p
