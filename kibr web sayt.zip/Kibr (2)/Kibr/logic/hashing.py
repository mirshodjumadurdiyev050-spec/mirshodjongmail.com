import hashlib

def sha256_hash(text):
    return hashlib.sha256(text.encode()).hexdigest()

def get_binary(hex_str):
    return bin(int(hex_str, 16))[2:].zfill(256)

def avalanche_effect(text1, text2):
    hash1 = sha256_hash(text1)
    hash2 = sha256_hash(text2)
    
    bin1 = get_binary(hash1)
    bin2 = get_binary(hash2)
    
    # Calculate bit difference
    diff_count = sum(b1 != b2 for b1, b2 in zip(bin1, bin2))
    percentage = (diff_count / 256) * 100
    
    return {
        "hash1": hash1,
        "hash2": hash2,
        "bin1": bin1,
        "bin2": bin2,
        "diff_bits": diff_count,
        "percentage": round(percentage, 2)
    }
